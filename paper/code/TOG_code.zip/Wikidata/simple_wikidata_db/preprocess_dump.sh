python preprocess_dump.py \
    --input_file /home/pengfan/test_project/ToG/Wikidata/latest-all.json.gz \
    --out_dir /home/pengfan/test_project/ToG/Wikidata/data \
    --batch_size 16 \
    --language_id en \
    --num_lines_read 1000000
python simple_wikidata_db/db_deploy/build_index.py \
    --input_dir /home/pengfan/test_project/ToG/Wikidata/data \
    --output_dir /home/pengfan/test_project/ToG/Wikidata/indices \
    --num_chunks 48 \
    --num_workers 32
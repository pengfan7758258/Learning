python simple_wikidata_db/db_deploy/server.py \
    --data_dir /home/pengfan/test_project/ToG/Wikidata/data \
    --chunk_number 1
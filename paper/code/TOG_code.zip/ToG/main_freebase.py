from tqdm import tqdm
import argparse
from utils import *
from freebase_func import *
import random
from client import *


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str,
                        default="webqsp", help="choose the dataset.")
    parser.add_argument("--max_length", type=int,
                        default=256, help="the max length of LLMs output.")
    parser.add_argument("--temperature_exploration", type=float,
                        default=0.4, help="the temperature in exploration stage.")
    parser.add_argument("--temperature_reasoning", type=float,
                        default=0, help="the temperature in reasoning stage.")
    parser.add_argument("--width", type=int,
                        default=3, help="choose the search width of ToG.")
    parser.add_argument("--depth", type=int,
                        default=3, help="choose the search depth of ToG.")
    parser.add_argument("--remove_unnecessary_rel", type=bool,
                        default=True, help="whether removing unnecessary relations.")
    parser.add_argument("--LLM_type", type=str,
                        default="gpt-3.5-turbo", help="base LLM model.")
    parser.add_argument("--opeani_api_keys", type=str,
                        default="", help="if the LLM_type is gpt-3.5-turbo or gpt-4, you need add your own openai api keys.")
    parser.add_argument("--num_retain_entity", type=int,
                        default=5, help="Number of entities retained during entities search.")
    parser.add_argument("--prune_tools", type=str,
                        default="llm", help="prune tools for ToG, can be llm (same as LLM_type), bm25 or sentencebert.")
    args = parser.parse_args()

    datas, question_string = prepare_dataset(args.dataset)
    print("Start Running ToG on %s dataset." % args.dataset)
    for data in tqdm(datas):
        question = data[question_string]
        topic_entity = data['topic_entity'] # 1.topic entities, 这里应该要使用LLM来提取
        cluster_chain_of_entities = []
        if len(topic_entity) == 0: # 2.没有topic entites直接根据llm回答问题
            results = generate_without_explored_paths(question, args)
            save_2_jsonl(question, results, [], file_name=args.dataset)
            continue
        pre_relations = []
        pre_heads= [-1] * len(topic_entity)
        flag_printed = False
        for depth in range(1, args.depth+1): # 3.深度depth
            current_entity_relations_list = []
            i=0
            for entity in topic_entity: # 4. 遍历topic entities，这里的entity是特殊的id
                if entity!="[FINISH_ID]":
                    # 5.关系探索，每个topic entities都会最多提取args.width个relation -- [{"entity": entity_id, "relation": relation, "score": score, "head": True},...]
                    # 假设有4个topic eneities,args.width是3，每个topic entity都要超过3的relation个数，最后会获得12个这样的dict组成的list
                    retrieve_relations_with_scores = relation_search_prune(entity, topic_entity[entity], pre_relations, pre_heads[i], question, args)  # best entity triplet, entitiy_id
                    current_entity_relations_list.extend(retrieve_relations_with_scores)
                i+=1
            total_candidates = []
            total_scores = []
            total_relations = []
            total_entities_id = []
            total_topic_entities = []
            total_head = []

            for entity in current_entity_relations_list: # 6.实体探索
                if entity['head']: # 7.搜索候选实体，确认了一个实体和一个关系的情况下找另一个实体，我看下面两个可以合并entity_search(entity['entity'], entity['relation'], entity['head'])
                    entity_candidates_id = entity_search(entity['entity'], entity['relation'], True)
                else:
                    entity_candidates_id = entity_search(entity['entity'], entity['relation'], False)
                
                if args.prune_tools == "llm": # 8.如果使用的llm prune，对于当前的实体候选集超过20则随机采样args.num_retain_entity（5）个
                    if len(entity_candidates_id) >=20:
                        entity_candidates_id = random.sample(entity_candidates_id, args.num_retain_entity)

                if len(entity_candidates_id) ==0:
                    continue
                scores, entity_candidates, entity_candidates_id = entity_score(question, entity_candidates_id, entity['score'], entity['relation'], args) # 9.获得当前图谱路径的最终候选实体集和它的打分，这个打分综合了关系的分数在里面
                # 10.对所有的三元组进行了保存
                total_candidates, total_scores, total_relations, total_entities_id, total_topic_entities, total_head = update_history(entity_candidates, entity, scores, entity_candidates_id, total_candidates, total_scores, total_relations, total_entities_id, total_topic_entities, total_head)
            
            if len(total_candidates) ==0: # 11.提前停止，没有候选实体
                half_stop(question, cluster_chain_of_entities, depth, args)
                flag_printed = True
                break
            # 12.实体剪枝 -- chain_of_entities保留的是前args.width的路径 [(tops[i], relations[i], candidates[i],...] 
            # pre_heads [True,False,True] pre_relations [关系1，关系2, 关系3]
            flag, chain_of_entities, entities_id, pre_relations, pre_heads = entity_prune(total_entities_id, total_relations, total_candidates, total_topic_entities, total_head, total_scores, args)
            cluster_chain_of_entities.append(chain_of_entities) # 13.加入整个路径
            if flag: # 14.推理一次，看现在的三元组能否回答给的问题
                stop, results = reasoning(question, cluster_chain_of_entities, args)
                if stop: # 15.已经可以回答问题，保存问题和答案还有三元组路径
                    print("ToG stoped at depth %d." % depth)
                    save_2_jsonl(question, results, cluster_chain_of_entities, file_name=args.dataset)
                    flag_printed = True
                    break
                else: # 16.不能回答问题
                    print("depth %d still not find the answer." % depth)
                    flag_finish, entities_id = if_finish_list(entities_id) # 判断entities_id是不是都没有了候选实体
                    if flag_finish: # 是的话提前停止，因为没有下一轮的topic entity了
                        half_stop(question, cluster_chain_of_entities, depth, args)
                        flag_printed = True
                    else: # 更新topic entity，进入下一轮
                        topic_entity = {entity: id2entity_name_or_type(entity) for entity in entities_id}
                        continue
            else:
                half_stop(question, cluster_chain_of_entities, depth, args)
                flag_printed = True
        
        if not flag_printed:
            results = generate_without_explored_paths(question, args)
            save_2_jsonl(question, results, [], file_name=args.dataset)
